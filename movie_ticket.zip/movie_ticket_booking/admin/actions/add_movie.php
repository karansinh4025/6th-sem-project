<?php
require_once './admin/config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $genre = $_POST['genre'];
    $duration = $_POST['duration'];

    // Image Upload Handling
    $file = $_FILES['poster'];
    $fileName = $file['name'];
    $fileTmpName = $file['tmp_name'];

    // Create unique name to avoid overwriting
    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));
    $newFileName = uniqid('', true) . "." . $fileActualExt;

    $fileDestination = '../../uploads/posters/' . $newFileName;

    if (move_uploaded_file($fileTmpName, $fileDestination)) {
        // SQL Insert
        $sql = "INSERT INTO movies (title, genre, duration, poster) VALUES (?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);

        if ($stmt->execute([$title, $genre, $duration, $newFileName])) {
            header("Location: ../manage_movies.php?upload=success");
        } else {
            echo "Database error.";
        }
    } else {
        echo "Failed to upload image.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Movie | CinemaPro Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: radial-gradient(circle at top, #1a1a1a, #000000);
            color: #fff;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.8);
        }
        .input-field {
            background: rgba(0, 0, 0, 0.4);
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }
        .input-field:focus {
            border-color: #e50914;
            box-shadow: 0 0 10px rgba(229, 9, 20, 0.3);
            outline: none;
        }
        .btn-netflix {
            background-color: #e50914;
            transition: transform 0.2s, background 0.2s;
        }
        .btn-netflix:hover {
            background-color: #b20710;
            transform: scale(1.02);
        }
    </style>
</head>
<body class="flex items-center justify-center p-6">

    <div class="glass-card w-full max-w-2xl rounded-2xl overflow-hidden">
        <div class="bg-white/5 p-6 border-b border-white/10 flex justify-between items-center">
            <h2 class="text-2xl font-bold italic tracking-tight">
                <span class="text-red-600">ADD</span> NEW MOVIE
            </h2>
            <a href="manage_movies.php" class="text-gray-400 hover:text-white transition">
                <i class="fas fa-times text-xl"></i>
            </a>
        </div>

        <form action="actions/add_movie.php" method="POST" enctype="multipart/form-data" class="p-8 space-y-6">
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="space-y-2">
                    <label class="text-sm text-gray-400 uppercase tracking-widest">Movie Title</label>
                    <input type="text" name="title" required placeholder="e.g. Inception" 
                           class="w-full input-field p-3 rounded-lg text-white">
                </div>

                <div class="space-y-2">
                    <label class="text-sm text-gray-400 uppercase tracking-widest">Genre</label>
                    <input type="text" name="genre" required placeholder="Action, Sci-Fi" 
                           class="w-full input-field p-3 rounded-lg text-white">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="space-y-2">
                    <label class="text-sm text-gray-400 uppercase tracking-widest">Duration (Minutes)</label>
                    <input type="number" name="duration" required placeholder="120" 
                           class="w-full input-field p-3 rounded-lg text-white">
                </div>

                <div class="space-y-2">
                    <label class="text-sm text-gray-400 uppercase tracking-widest">Movie Poster (Image)</label>
                    <div class="relative">
                        <input type="file" name="poster" id="poster" accept="image/*" required class="hidden">
                        <label for="poster" class="w-full flex items-center justify-between input-field p-3 rounded-lg cursor-pointer text-gray-400 hover:bg-white/5">
                            <span id="file-name">Choose file...</span>
                            <i class="fas fa-cloud-upload-alt text-red-600"></i>
                        </label>
                    </div>
                </div>
            </div>

            <div class="space-y-2">
                <label class="text-sm text-gray-400 uppercase tracking-widest">Description</label>
                <textarea name="description" rows="3" placeholder="Enter movie synopsis..." 
                          class="w-full input-field p-3 rounded-lg text-white"></textarea>
            </div>

            <div class="flex items-center gap-4 pt-4">
                <button type="submit" class="flex-1 btn-netflix p-4 rounded-lg font-bold text-lg uppercase tracking-widest">
                    Save Movie to Catalog
                </button>
                <button type="reset" class="px-6 py-4 rounded-lg border border-gray-600 hover:bg-white/5 text-gray-300 transition">
                    Reset
                </button>
            </div>
        </form>
    </div>

    <script>
        document.getElementById('poster').onchange = function () {
            document.getElementById('file-name').innerText = this.files[0].name;
            document.getElementById('file-name').classList.remove('text-gray-400');
            document.getElementById('file-name').classList.add('text-white');
        };
    </script>

</body>
</html>