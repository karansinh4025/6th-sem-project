-- ============================================
-- Movie Ticket Booking System Database
-- ============================================

-- 1. Create Database
CREATE DATABASE IF NOT EXISTS movie_booking;
USE movie_booking;

-- ============================================
-- 2. Users Table
-- ============================================
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(15) NOT NULL
);

-- ============================================
-- 3. Movies Table
-- ============================================
CREATE TABLE movies (
    movie_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    genre VARCHAR(50),
    duration VARCHAR(20),
    language VARCHAR(30),
    poster VARCHAR(255)
);

-- ============================================
-- 4. Theaters Table
-- ============================================
CREATE TABLE theaters (
    theater_id INT AUTO_INCREMENT PRIMARY KEY,
    theater_name VARCHAR(100) NOT NULL,
    location VARCHAR(100)
);

-- ============================================
-- 5. Shows Table
-- ============================================
CREATE TABLE shows (
    show_id INT AUTO_INCREMENT PRIMARY KEY,
    movie_id INT NOT NULL,
    theater_id INT NOT NULL,
    show_date DATE NOT NULL,
    show_time TIME NOT NULL,
    FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON DELETE CASCADE,
    FOREIGN KEY (theater_id) REFERENCES theaters(theater_id) ON DELETE CASCADE
);

-- ============================================
-- 6. Seats Table
-- ============================================
CREATE TABLE seats (
    seat_id INT AUTO_INCREMENT PRIMARY KEY,
    show_id INT NOT NULL,
    seat_number VARCHAR(10) NOT NULL,
    status ENUM('Available','Booked') DEFAULT 'Available',
    FOREIGN KEY (show_id) REFERENCES shows(show_id) ON DELETE CASCADE
);

-- ============================================
-- 7. Bookings Table
-- ============================================
CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    show_id INT NOT NULL,
    seats VARCHAR(100) NOT NULL,
    booking_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_price INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (show_id) REFERENCES shows(show_id) ON DELETE CASCADE
);

-- ============================================
-- 8. Sample Data (For Demo)
-- ============================================

-- Movies
INSERT INTO movies (title, genre, duration, language) VALUES
('Avengers Endgame','Action','3 Hours','English'),
('KGF Chapter 2','Action','2.5 Hours','Hindi'),
('Inception','Sci-Fi','2.8 Hours','English');

-- Theaters
INSERT INTO theaters (theater_name, location) VALUES
('PVR Cinemas','City Center'),
('INOX','Mall Road');

-- Shows
INSERT INTO shows (movie_id, theater_id, show_date, show_time) VALUES
(1,1,'2025-01-10','18:00:00'),
(1,2,'2025-01-10','21:00:00'),
(2,1,'2025-01-11','19:00:00');

-- Seats for Show 1
INSERT INTO seats (show_id, seat_number) VALUES
(1,'A1'),(1,'A2'),(1,'A3'),(1,'A4'),
(1,'B1'),(1,'B2'),(1,'B3'),(1,'B4');

-- Seats for Show 2
INSERT INTO seats (show_id, seat_number) VALUES
(2,'A1'),(2,'A2'),(2,'A3'),(2,'A4'),
(2,'B1'),(2,'B2'),(2,'B3'),(2,'B4');

-- ============================================
-- End of SQL File
-- ============================================
