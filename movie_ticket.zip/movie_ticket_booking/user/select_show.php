<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$movie_id = mysqli_real_escape_string($conn, $_GET['movie_id']);

// Fetch Movie Details for the Header
$movie_query = mysqli_query($conn, "SELECT title FROM movies WHERE movie_id=$movie_id");
$movie = mysqli_fetch_assoc($movie_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Select Show - <?php echo $movie['title']; ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background-color: #0f0f0f; color: white; padding: 40px 5%; }

        .header { margin-bottom: 40px; border-bottom: 1px solid #333; padding-bottom: 20px; }
        .header h1 { color: #ff4d4d; font-size: 28px; }
        .header p { color: #aaa; margin-top: 5px; }

        .show-container {
            background: #1e1e1e;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }

        .date-section { margin-bottom: 30px; }
        .date-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            color: #efefef;
        }
        .date-title::before {
            content: '';
            width: 4px;
            height: 20px;
            background: #ff4d4d;
            margin-right: 10px;
            border-radius: 2px;
        }

        .time-slots {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }

        .slot-link {
            text-decoration: none;
            color: #28a745; /* Green for available vibe */
            border: 1px solid #28a745;
            padding: 10px 25px;
            border-radius: 5px;
            font-weight: 500;
            font-size: 14px;
            transition: 0.3s;
            background: transparent;
        }

        .slot-link:hover {
            background: #28a745;
            color: white;
            box-shadow: 0 0 15px rgba(40, 167, 69, 0.4);
            transform: translateY(-3px);
        }

        .no-shows { color: #888; font-style: italic; }
        
        .back-btn {
            display: inline-block;
            margin-top: 20px;
            color: #ff4d4d;
            text-decoration: none;
            font-size: 14px;
        }
    </style>
</head>
<body>

<div class="header">
    <h1><?php echo $movie['title']; ?></h1>
    <p>Select your preferred date and time to book tickets</p>
</div>

<div class="show-container">
    <?php
    // Fetch unique dates for this movie
    $date_result = mysqli_query($conn, "SELECT DISTINCT show_date FROM shows WHERE movie_id=$movie_id ORDER BY show_date ASC");
    
    if (mysqli_num_rows($date_result) > 0) {
        while ($date_row = mysqli_fetch_assoc($date_result)) {
            $current_date = $date_row['show_date'];
            // Format date for display (e.g., 12 Oct 2025)
            $formatted_date = date("d M, Y", strtotime($current_date));
            ?>
            
            <div class="date-section">
                <div class="date-title"><?php echo $formatted_date; ?></div>
                <div class="time-slots">
                    <?php
                    // Fetch all times for this specific date
                    $time_result = mysqli_query($conn, "SELECT * FROM shows WHERE movie_id=$movie_id AND show_date='$current_date' ORDER BY show_time ASC");
                    while ($show = mysqli_fetch_assoc($time_result)) {
                        // Format time to 12-hour format (e.g., 06:00 PM)
                        $formatted_time = date("h:i A", strtotime($show['show_time']));
                        echo "<a href='select_seats.php?show_id={$show['show_id']}' class='slot-link'>$formatted_time</a>";
                    }
                    ?>
                </div>
            </div>

            <?php
        }
    } else {
        echo "<p class='no-shows'>No shows currently scheduled for this movie.</p>";
    }
    ?>
</div>

<a href="dashboard.php" class="back-btn">← Back to Movies</a>

</body>
</html>