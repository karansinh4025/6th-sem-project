<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || !isset($_POST['seats'])) {
    header("Location: dashboard.php");
    exit();
}

$show_id = $_POST['show_id'];
$seats = $_POST['seats']; // Array of seats
$seat_string = implode(",", $seats);
$total_seats = count($seats);
$price_per_seat = 150;
$total_amount = $total_seats * $price_per_seat;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Payment Gateway - CinemaPro</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: #0f0f0f;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .payment-container {
            background: #1a1a1a;
            width: 100%;
            max-width: 500px;
            padding: 30px;
            border-radius: 15px;
            border: 1px solid #333;
        }

        .summary {
            background: #252525;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 25px;
            border-left: 4px solid #ff4d4d;
        }

        .summary h3 {
            font-size: 16px;
            margin-bottom: 5px;
        }

        .summary p {
            font-size: 14px;
            color: #aaa;
        }

        .payment-methods {
            display: flex;
            gap: 10px;
            margin-bottom: 25px;
        }

        .method-btn {
            flex: 1;
            padding: 12px;
            border: 1px solid #444;
            background: #222;
            color: white;
            border-radius: 8px;
            cursor: pointer;
            transition: 0.3s;
            text-align: center;
            font-size: 14px;
        }

        .method-btn.active {
            border-color: #ff4d4d;
            background: rgba(255, 77, 77, 0.1);
            color: #ff4d4d;
        }

        .payment-form {
            display: none;
        }

        .payment-form.active {
            display: block;
        }

        input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            background: #333;
            border: 1px solid #444;
            color: white;
            border-radius: 5px;
        }

        .pay-now-btn {
            width: 100%;
            padding: 15px;
            background: #2ecc71;
            border: none;
            color: white;
            font-weight: bold;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 20px;
            transition: 0.3s;
        }

        .pay-now-btn:hover {
            background: #27ae60;
            transform: translateY(-2px);
        }

        .offline-notice {
            color: #aaa;
            font-size: 13px;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>

<body>

    <div class="payment-container">
        <h2 style="margin-bottom: 20px; text-align: center;">Secure Payment</h2>

        <div class="summary">
            <h3>Order Summary</h3>
            <p>Seats: <?php echo $seat_string; ?> (<?php echo $total_seats; ?> Tickets)</p>
            <p style="color: #ff4d4d; font-weight: bold; margin-top: 5px;">Total Payable: ₹<?php echo $total_amount; ?></p>
        </div>

        <div class="payment-methods">
            <div class="method-btn active" onclick="showMethod('online')">Online Payment</div>
            <div class="method-btn" onclick="showMethod('offline')">Pay at Counter</div>
        </div>

        <form action="book_ticket.php" method="post">
            <input type="hidden" name="show_id" value="<?php echo $show_id; ?>">
            <?php foreach ($seats as $s) echo '<input type="hidden" name="seats[]" value="' . $s . '">'; ?>

            <div id="online-form" class="payment-form active">
                <input type="text" placeholder="Cardholder Name" required>
                <input type="text" placeholder="Card Number (xxxx xxxx xxxx xxxx)" maxlength="16" required>
                <div style="display: flex; gap: 10px;">
                    <input type="text" placeholder="MM/YY" maxlength="5" required>
                    <input type="password" placeholder="CVV" maxlength="3" required>
                </div>
                <input type="hidden" name="payment_method" value="Online">
                <button type="submit" name="book" class="pay-now-btn">Pay & Book Now</button>
            </div>

            <div id="offline-form" class="payment-form">
                <div class="offline-notice">
                    <p>You can pay cash at the cinema box office 30 minutes before the show.</p>
                    <input type="hidden" name="payment_method" value="Offline">
                    <button type="submit" name="book" class="pay-now-btn" style="background: #ff4d4d;">Confirm Reservation</button>
                </div>
            </div>
        </form>
    </div>

    <script>
        function showMethod(method) {
            document.querySelectorAll('.payment-form').forEach(f => f.classList.remove('active'));
            document.querySelectorAll('.method-btn').forEach(b => b.classList.remove('active'));

            document.getElementById(method + '-form').classList.add('active');
            event.currentTarget.classList.add('active');
        }
    </script>

</body>

</html>