<?php
session_start();
include "../config/db.php";

// Redirect to login if session is not set
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Movie Booking</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        /* CSS for Dashboard */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: #0f0f0f;
            color: white;
        }

        /* Navigation Bar */
        nav {
            background: #1a1a1a;
            padding: 15px 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        }

        nav h1 {
            color: #ff4d4d;
            font-size: 24px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            font-size: 14px;
            transition: 0.3s;
        }

        .logout-btn {
            background: #ff4d4d;
            padding: 8px 18px;
            border-radius: 5px;
            font-weight: 600;
        }

        /* Container */
        .container {
            padding: 40px 5%;
        }

        h2 {
            margin-bottom: 30px;
            font-weight: 600;
            letter-spacing: 1px;
            border-left: 5px solid #ff4d4d;
            padding-left: 15px;
        }

        /* Movie Grid */
        .movie-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 30px;
        }

        /* Movie Card */
        .movie-card {
            background: #1e1e1e;
            border-radius: 12px;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: 1px solid #333;
        }

        .movie-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 25px rgba(255, 77, 77, 0.3);
            border-color: #ff4d4d;
        }

        .movie-poster {
            width: 100%;
            height: 350px;
            background: #333;
            /* Placeholder color */
            object-fit: cover;
        }

        .movie-info {
            padding: 20px;
        }

        .movie-info h4 {
            font-size: 18px;
            margin-bottom: 10px;
            color: #fff;
        }

        .movie-info p {
            font-size: 13px;
            color: #aaa;
            margin-bottom: 15px;
        }

        .book-btn {
            display: block;
            text-align: center;
            background: #ff4d4d;
            color: white;
            text-decoration: none;
            padding: 10px;
            border-radius: 6px;
            font-weight: 600;
            transition: 0.3s;
        }

        .book-btn:hover {
            background: #cc0000;
        }
    </style>
</head>

<body>

    <nav>
        <h1>🎬 CinemaPro</h1>
        <div class="nav-links">
            <a href="dashboard.php">Home</a>
            <a href="my_bookings.php">My Bookings</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </nav>

    <div class="container">
        <h2>Now Showing</h2>

        <div class="movie-grid">
            <?php
            $result = mysqli_query($conn, "SELECT * FROM movies");
            while ($row = mysqli_fetch_assoc($result)) {
                // Using a placeholder image if poster path is empty
                $imagePath = !empty($row['poster']) ? $row['poster'] : 'https://via.placeholder.com/300x450?text=No+Poster';
            ?>

                <div class="movie-card">
                    <img src="<?php echo $imagePath; ?>" alt="Movie Poster" class="movie-poster">
                    <div class="movie-info">
                        <h4><?php echo $row['title']; ?></h4>
                        <p><?php echo $row['genre']; ?> | <?php echo $row['duration']; ?></p>
                        <a href="select_show.php?movie_id=<?php echo $row['movie_id']; ?>" class="book-btn">Book Tickets</a>
                    </div>
                </div>

            <?php } ?>
        </div>
    </div>

</body>

</html>