<?php 
include "../config/db.php"; 
$msg = ""; // To store success or error messages

if (isset($_POST['register'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);

    // Check if email already exists
    $checkEmail = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if(mysqli_num_rows($checkEmail) > 0) {
        $msg = "<div class='error-msg'>Email already registered!</div>";
    } else {
        $query = "INSERT INTO users VALUES (NULL,'$name','$email','$password','$phone')";
        if(mysqli_query($conn, $query)) {
            $msg = "<div class='success-msg'>Registration Successful! <a href='login.php'>Login Now</a></div>";
        } else {
            $msg = "<div class='error-msg'>Error: Could not register.</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Registration - Movie Booking</title>
    <style>
        /* Shared CSS from Login Page */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        
        body { 
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), 
                        url('https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1350&q=80'); 
            background-size: cover; 
            background-position: center; 
            min-height: 100vh; 
            display: flex; 
            align-items: center; 
            justify-content: center;
            padding: 20px;
        }

        .register-wrapper { width: 100%; display: flex; justify-content: center; }

        .register-card { 
            background: rgba(255, 255, 255, 0.1); 
            backdrop-filter: blur(10px); 
            padding: 30px 40px; 
            border-radius: 15px; 
            width: 100%; 
            max-width: 450px; 
            border: 1px solid rgba(255, 255, 255, 0.1); 
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.5); 
            color: white; 
            text-align: center;
        }

        h2 { margin-bottom: 25px; font-size: 1.8rem; color: #ff4d4d; letter-spacing: 1px; }

        .input-group { position: relative; margin-bottom: 18px; text-align: left; }
        .input-group label { display: block; font-size: 13px; color: #e0e0e0; margin-bottom: 5px; }
        
        .input-group input { 
            width: 100%; 
            padding: 12px 15px; 
            font-size: 15px; 
            background: rgba(255, 255, 255, 0.08); 
            border: 1px solid rgba(255, 255, 255, 0.2); 
            border-radius: 8px; 
            color: #ffffff; 
            outline: none; 
            transition: 0.3s; 
        }

        .input-group input:focus { 
            border-color: #ff4d4d; 
            box-shadow: 0 0 10px rgba(255, 77, 77, 0.4); 
            background: rgba(255, 255, 255, 0.15);
        }

        .register-btn { 
            width: 100%; 
            padding: 14px; 
            background: linear-gradient(135deg, #ff4d4d 0%, #b30000 100%); 
            color: white; 
            border: none; 
            border-radius: 8px; 
            font-size: 16px; 
            font-weight: 700; 
            text-transform: uppercase; 
            cursor: pointer; 
            transition: 0.3s; 
            margin-top: 10px;
        }

        .register-btn:hover { transform: scale(1.02); box-shadow: 0 5px 15px rgba(255, 77, 77, 0.4); }

        .error-msg, .success-msg { 
            padding: 10px; border-radius: 5px; margin-bottom: 15px; font-size: 0.9rem; 
        }
        .error-msg { background: rgba(255, 0, 0, 0.2); color: #ff9999; border: 1px solid #ff4d4d; }
        .success-msg { background: rgba(0, 255, 0, 0.1); color: #99ff99; border: 1px solid #00ff00; }
        .success-msg a { color: white; font-weight: bold; }

        .footer-links { margin-top: 20px; font-size: 0.9rem; color: #bbb; }
        .footer-links a { color: #ff4d4d; text-decoration: none; }
    </style>
</head>
<body>

<div class="register-wrapper">
    <div class="register-card">
        <h2>Create Account</h2>

        <?php echo $msg; ?>

        <form method="post">
            <div class="input-group">
                <label>Full Name</label>
                <input type="text" name="name" placeholder="John Doe" required>
            </div>

            <div class="input-group">
                <label>Email Address</label>
                <input type="email" name="email" placeholder="john@example.com" required>
            </div>

            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="••••••••" required>
            </div>

            <div class="input-group">
                <label>Phone Number</label>
                <input type="text" name="phone" placeholder="+91 0000000000" required>
            </div>

            <button type="submit" name="register" class="register-btn">Register Now</button>
        </form>

        <div class="footer-links">
            <p>Already have an account? <a href="login.php">Login here</a></p>
        </div>
    </div>
</div>

</body>
</html>