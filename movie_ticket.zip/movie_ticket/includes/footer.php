<style>
.netflix-footer {
    background-color: #000;
    color: #757575;
    padding: 80px 5% 30px;
    font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
    border-top: 8px solid #222;
}

.footer-flex-container {
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    /* Pushes brand left and links right */
    align-items: flex-start;
    gap: 50px;
}

/* Left Side Styling */
.footer-brand-side {
    flex: 1;
    /* Takes up necessary space on the left */
}

.footer-heading {
    color: #e50914;
    font-size: 32px;
    font-weight: 900;
    letter-spacing: -1px;
    margin: 0 0 10px 0;
}

.pro-tag {
    background-color: #e50914;
    color: #fff;
    padding: 2px 8px;
    border-radius: 3px;
    font-size: 16px;
    vertical-align: middle;
}

.brand-tagline {
    font-size: 14px;
    margin-bottom: 20px;
}

/* Right Side Styling */
.footer-links-side {
    flex: 2;
    /* Takes up more space for the grid */
}

.footer-links-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    /* 3 columns for links */
    gap: 40px;
}

.footer-column {
    display: flex;
    flex-direction: column;
}

.footer-column a {
    color: #757575;
    text-decoration: none;
    font-size: 14px;
    margin-bottom: 15px;
    transition: color 0.2s;
}

.footer-column a:hover {
    color: #fff;
    text-decoration: underline;
}

/* Icons & Bottom */
.social-icons i {
    margin-right: 15px;
    font-size: 18px;
    color: #757575;
    cursor: pointer;
}

.social-icons i:hover {
    color: #fff;
}

.footer-bottom {
    max-width: 1200px;
    margin: 50px auto 0;
    padding-top: 20px;
    border-top: 1px solid #333;
    font-size: 12px;
}

/* Responsive: Stack them on top of each other on mobile */
@media (max-width: 850px) {
    .footer-flex-container {
        flex-direction: column;
        text-align: center;
    }

    .footer-brand-side {
        margin-bottom: 40px;
    }

    .footer-links-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
    }
}
</style>
<footer class="netflix-footer">
    <div class="footer-flex-container">

        <div class="footer-brand-side">
            <a href="index.php" class="brand-link">
                <h1 class="footer-heading">CINEMA <span class="pro-tag">PRO</span></h1>
            </a>
            <p class="brand-tagline">Experience the future of cinema.</p>
            <div class="social-icons">
                <i class="fab fa-facebook-f"></i>
                <i class="fab fa-twitter"></i>
                <i class="fab fa-instagram"></i>
            </div>
        </div>

        <div class="footer-links-side">
            <div class="footer-links-grid">
                <div class="footer-column">
                    <a href="#">FAQ</a>
                    <a href="#">Account</a>
                    <a href="#">Investor Relations</a>
                    <a href="#">Privacy</a>
                </div>
                <div class="footer-column">
                    <a href="#">Help Center</a>
                    <a href="#">Ways to Watch</a>
                    <a href="#">Jobs</a>
                    <a href="#">Legal Notices</a>
                </div>
                <div class="footer-column">
                    <a href="#">Media Center</a>
                    <a href="#">Terms of Use</a>
                    <a href="contact-us.php">Contact Us</a>
                    <a href="#">Corporate Info</a>
                </div>
            </div>
        </div>

    </div>

    <div class="footer-bottom">
        <p>© 2020-2025 Cinema Pro. Created by karansinh</p>
    </div>
</footer>