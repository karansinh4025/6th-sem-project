<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        /* --- CINEMA PRO NAVBAR STYLES --- */
        :root {
            --primary-color: #e50914;
            --glass-border: rgba(255, 255, 255, 0.1);
        }

        header {
            background: rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border-bottom: 1px solid var(--glass-border);
            height: 70px;
            width: 100%;
            position: fixed;
            top: 0;
            z-index: 1000;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 5%;
            box-sizing: border-box;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
        }

        .navbar-brand {
            display: flex;
            align-items: center;
            text-decoration: none;
        }

        .navbar-brand h2 {
            margin: 0;
            font-size: 1.8rem;
            color: white;
            font-weight: 700;
            letter-spacing: 1px;
            display: inline-block;
        }

        .navbar-brand span {
            color: var(--primary-color);
        }

        .nav-links {
            list-style: none;
            display: flex;
            gap: 30px;
            margin: 0;
            padding: 0;
        }

        .nav-links li a {
            text-decoration: none;
            color: #ccc;
            font-weight: 500;
            transition: color 0.3s ease;
            font-size: 1rem;
        }

        .nav-links li a:hover,
        .nav-links li a.active {
            color: white;
            text-shadow: 0 0 10px rgba(255, 255, 255, 0.5);
        }

        .btn-signin {
            background-color: var(--primary-color);
            color: white;
            padding: 8px 20px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: bold;
            transition: background 0.3s ease, transform 0.2s;
            border: none;
            box-shadow: 0 4px 10px rgba(229, 9, 20, 0.3);
        }

        .btn-signin:hover {
            background-color: #ff1f2c;
            transform: scale(1.05);
        }
    </style>
</head>

<body>
    <header>
        <a href="index.php" class="navbar-brand">
            <h2>Cinema<span>Pro</span></h2>
        </a>

        <ul class="nav-links">
            <li><a href="index.php#home-section-1" class="active">Home</a></li>
            <li><a href="index.php#home-section-1">Movies</a></li>
            <li><a href="index.php#home-section-3">Trailers</a></li>
            <li><a href="index.php#home-section-2">About</a></li>
        </ul>

        <a href="login.php" class="btn-signin">Sign In</a>
    </header>
</body>

</html>