<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CinemaPro - Netflix Style</title>
    <style>
    /* --- NETFLIX COLOR PALETTE --- */
    :root {
        --primary-red: #e50914;
        --hover-red: #f40612;
        --bg-black: #000000;
        --text-white: #ffffff;
        --text-grey: #b3b3b3;
        /* Classic Netflix subtitle/secondary color */
        --glass-border: rgba(255, 255, 255, 0.1);
    }

    body {
        margin: 0;
        padding-top: 70px;
        background-color: var(--bg-black);
        color: var(--text-white);
        font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
        /* Netflix-style font stack */
        -webkit-font-smoothing: antialiased;
    }

    html {
        scroll-behavior: smooth;
        scroll-padding-top: 70px;
    }

    /* --- NAVBAR STYLES --- */
    header {
        background: linear-gradient(to bottom, rgba(0, 0, 0, 0.8) 0%, rgba(0, 0, 0, 0) 100%);
        /* Fade effect */
        background-color: var(--bg-black);
        height: 70px;
        width: 100%;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 1000;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 4%;
        box-sizing: border-box;
        transition: background-color 0.5s;
    }

    .navbar-brand {
        display: flex;
        align-items: center;
        text-decoration: none;
    }

    .navbar-brand h2 {
        margin: 0;
        font-size: 1.8rem;
        color: var(--primary-red);
        /* Logo usually primary red */
        font-weight: 900;
        letter-spacing: -1px;
        text-transform: uppercase;
    }

    .navbar-brand span {
        color: var(--text-white);
        /* High contrast suffix */
    }

    .nav-links {
        list-style: none;
        display: flex;
        gap: 20px;
        margin: 0;
        padding: 0;
    }

    .nav-links li a {
        text-decoration: none;
        color: var(--text-grey);
        font-weight: 400;
        transition: color 0.3s ease;
        font-size: 0.9rem;
    }

    .nav-links li a:hover,
    .nav-links li a.active {
        color: var(--text-white);
    }

    /* --- ACTION BUTTON --- */
    .btn-signin {
        background-color: var(--primary-red);
        color: var(--text-white);
        padding: 7px 17px;
        border-radius: 3px;
        text-decoration: none;
        font-size: 0.9rem;
        font-weight: 500;
        transition: background 0.2s ease;
        border: none;
    }

    .btn-signin:hover {
        background-color: var(--hover-red);
    }

    /* --- CONTENT TYPOGRAPHY GUIDE --- */
    .section-title {
        color: var(--text-white);
        font-size: 2.5rem;
        margin-bottom: 0;
    }

    .section-subtitle {
        color: var(--text-grey);
        /* Instead of yellow or pure white */
        font-size: 1.2rem;
        font-weight: 400;
    }
    </style>
</head>

<body>
    <header>
        <a href="index.php" class="navbar-brand">
            <h2>Cinema<span>Pro</span></h2>
        </a>

        <ul class="nav-links">
            <li><a href="index.php#home-section-1" class="active">Home</a></li>
            <li><a href="index.php#home-section-1">Movies</a></li>
            <li><a href="index.php#home-section-3">Trailers</a></li>
            <li><a href="index.php#home-section-2">About</a></li>
        </ul>

        <a href="login.php" class="btn-signin">Sign In</a>
    </header>
</body>

</html>