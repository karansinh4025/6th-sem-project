<?php
    session_start();
    include '../config.php';
?>