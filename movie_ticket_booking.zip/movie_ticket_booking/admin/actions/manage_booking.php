<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Movies | CinemaPro Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #000;
            background-image: radial-gradient(circle at 20% 30%, #1a1a1a 0%, #000 100%);
            color: #fff;
            min-height: 100vh;
        }

        .glass {
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .movie-card:hover .overlay {
            opacity: 1;
        }

        .netflix-red {
            color: #e50914;
        }

        .bg-netflix-red {
            background-color: #e50914;
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #000;
        }

        ::-webkit-scrollbar-thumb {
            background: #333;
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #e50914;
        }
    </style>
</head>

<body class="flex">

  
    <main class="flex-1 p-8">
        <div class="flex justify-between items-center mb-10">
            <div>
                <h1 class="text-4xl font-bold tracking-tight">Manage <span class="netflix-red">Movies</span></h1>
                <p class="text-gray-400">Add, update, or remove movies from the catalog.</p>
            </div>
            <button onclick="document.getElementById('addMovieModal').classList.toggle('hidden')"
                class="bg-netflix-red hover:bg-red-700 px-6 py-3 rounded-lg font-bold flex items-center gap-2 transition transform hover:scale-105">
                <i class="fas fa-plus"></i> Add New Movie
            </button>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            <div class="glass p-5 rounded-xl flex items-center gap-4">
                <div class="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center netflix-red">
                    <i class="fas fa-film fa-lg"></i>
                </div>
                <div>
                    <p class="text-gray-400 text-xs uppercase">Total Movies</p>
                    <h3 class="text-xl font-bold">42</h3>
                </div>
            </div>
        </div>

        <div class="glass rounded-2xl overflow-hidden">
            <div class="p-6 border-b border-white/10 flex justify-between items-center bg-white/5">
                <h2 class="font-semibold text-lg text-gray-200">Current Movie Catalog</h2>
                <div class="relative">
                    <input type="text" placeholder="Search movies..." class="bg-black/40 border border-white/10 rounded-full py-2 px-4 pl-10 text-sm focus:outline-none focus:border-red-600 w-64">
                    <i class="fas fa-search absolute left-4 top-3 text-gray-500 text-xs"></i>
                </div>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="text-gray-400 text-sm uppercase tracking-wider border-b border-white/10">
                            <th class="p-5">Poster</th>
                            <th class="p-5">Title & Genre</th>
                            <th class="p-5 text-center">Duration</th>
                            <th class="p-5 text-center">Shows</th>
                            <th class="p-5 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-white/5">
                        <tr class="hover:bg-white/5 transition">
                            <td class="p-5 w-24">
                                <img src="https://via.placeholder.com/150x220" alt="Poster" class="w-16 h-24 object-cover rounded shadow-lg border border-white/10">
                            </td>
                            <td class="p-5">
                                <div class="font-bold text-white text-lg">Inception</div>
                                <div class="text-gray-500 text-sm italic">Sci-Fi, Action</div>
                            </td>
                            <td class="p-5 text-center text-gray-300">148 mins</td>
                            <td class="p-5 text-center">
                                <span class="bg-green-500/10 text-green-500 px-3 py-1 rounded-full text-xs border border-green-500/20">5 Active Shows</span>
                            </td>
                            <td class="p-5 text-right">
                                <div class="flex justify-end gap-3">
                                    <button class="w-9 h-9 rounded-lg bg-blue-500/10 text-blue-500 hover:bg-blue-500 hover:text-white transition"><i class="fas fa-edit"></i></button>
                                    <button class="w-9 h-9 rounded-lg bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white transition"><i class="fas fa-trash"></i></button>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <div id="addMovieModal" class="hidden fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-50 p-4">
        <div class="glass w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300">
            <div class="p-6 border-b border-white/10 flex justify-between items-center">
                <h3 class="text-xl font-bold">Add <span class="netflix-red">New Movie</span></h3>
                <button onclick="document.getElementById('addMovieModal').classList.add('hidden')" class="text-gray-400 hover:text-white"><i class="fas fa-times"></i></button>
            </div>
            <form action="actions/add_movie.php" method="POST" enctype="multipart/form-data" class="p-8 space-y-5">
                <div class="grid grid-cols-2 gap-4">
                    <div class="col-span-2">
                        <label class="block text-xs uppercase text-gray-400 mb-2 tracking-widest">Movie Title</label>
                        <input type="text" name="title" required class="w-full bg-black/40 border border-white/10 rounded-lg p-3 text-white focus:border-red-600 focus:outline-none">
                    </div>
                    <div>
                        <label class="block text-xs uppercase text-gray-400 mb-2 tracking-widest">Genre</label>
                        <input type="text" name="genre" placeholder="e.g. Action" class="w-full bg-black/40 border border-white/10 rounded-lg p-3 text-white focus:border-red-600 focus:outline-none">
                    </div>
                    <div>
                        <label class="block text-xs uppercase text-gray-400 mb-2 tracking-widest">Duration (Min)</label>
                        <input type="number" name="duration" class="w-full bg-black/40 border border-white/10 rounded-lg p-3 text-white focus:border-red-600 focus:outline-none">
                    </div>
                    <div class="col-span-2">
                        <label class="block text-xs uppercase text-gray-400 mb-2 tracking-widest">Poster Image</label>
                        <input type="file" name="poster" accept="image/*" class="w-full text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:bg-red-600/10 file:text-red-500 hover:file:bg-red-600/20 cursor-pointer">
                    </div>
                </div>
                <button type="submit" class="w-full bg-netflix-red py-3 rounded-lg font-bold text-lg mt-4 hover:shadow-[0_0_20px_rgba(229,9,20,0.4)] transition">Save Movie</button>
            </form>
        </div>
    </div>

</body>

</html>