<?php
session_start();
require_once './config/db.php'; // Ensure this file has your $pdo connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // 1. Fetch user by email
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // 2. Verify password (using password_verify for security)
    if ($user && password_verify($password, $user['password'])) {
        // Create Sessions
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_role'] = $user['role'];

        // 3. Redirect based on role
        if ($user['role'] === 'admin') {
            header("Location: ../../admin/index.php");
        } else {
            header("Location: ../../views/user/dashboard.php");
        }
        exit();
    } else {
        header("Location: ../../views/public/login.php?error=1");
        exit();
    }
} ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Login | CinemaPro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: #000;
            color: #fff;
        }

        .glass {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .netflix-red {
            background-color: #e50914;
        }
    </style>
</head>

<body class="flex items-center justify-center min-h-screen">
    <div class="glass p-10 rounded-2xl w-full max-w-md shadow-2xl">
        <h2 class="text-3xl font-bold mb-6 text-center"><span class="text-red-600">CINEMA</span>PRO</h2>

        <?php if (isset($_GET['error'])): ?>
            <div class="bg-red-500/20 text-red-500 p-3 rounded mb-4 text-sm border border-red-500/50">
                Invalid email or password.
            </div>
        <?php endif; ?>

        <form action="../../modules/auth/login_process.php" method="POST" class="space-y-6">
            <div>
                <label class="block text-sm text-gray-400 mb-2">Email Address</label>
                <input type="email" name="email" required class="w-full bg-gray-800/50 border border-gray-700 rounded-lg p-3 focus:outline-none focus:border-red-600 transition">
            </div>
            <div>
                <label class="block text-sm text-gray-400 mb-2">Password</label>
                <input type="password" name="password" required class="w-full bg-gray-800/50 border border-gray-700 rounded-lg p-3 focus:outline-none focus:border-red-600 transition">
            </div>
            <button type="submit" class="w-full netflix-red py-3 rounded-lg font-bold hover:bg-red-700 transition duration-300">Sign In</button>
        </form>

        <p class="mt-6 text-center text-gray-400 text-sm">
            New to CinemaPro? <a href="register.php" class="text-white hover:underline">Sign up now</a>.
        </p>
    </div>
</body>

</html>