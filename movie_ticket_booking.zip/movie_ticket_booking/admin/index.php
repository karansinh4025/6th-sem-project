<?php
// require_once 'includes/admin_auth.php'; // Uncomment once auth is ready
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | CinemaPro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: radial-gradient(circle at top left, #1a1a1a, #000000);
            color: #ffffff;
            min-height: 100vh;
        }

        .glass {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 1rem;
        }

        .netflix-red {
            color: #e50914;
        }

        .bg-netflix-red {
            background-color: #e50914;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.1);
        }
    </style>
</head>

<body class="flex">

    <aside class="w-64 h-screen sticky top-0 bg-black border-r border-gray-800 p-6 flex flex-col">
        <div class="mb-10 text-2xl font-bold tracking-tighter">
            <span class="netflix-red">CINEMA</span>PRO
        </div>

        <nav class="flex-1 space-y-4">
            <a href="index.php" class="flex items-center space-x-3 p-3 glass bg-netflix-red bg-opacity-20 text-white">
                <i class="fas fa-chart-line"></i>
                <span>Dashboard</span>
            </a>
            <a href="manage_movies.php" class="flex items-center space-x-3 p-3 hover:text-red-500 transition">
                <i class="fas fa-film"></i>
                <span>Manage Movies</span>
            </a>
            <a href="manage_shows.php" class="flex items-center space-x-3 p-3 hover:text-red-500 transition">
                <i class="fas fa-calendar-alt"></i>
                <span>Show Schedules</span>
            </a>
            <a href="manage_bookings.php" class="flex items-center space-x-3 p-3 hover:text-red-500 transition">
                <i class="fas fa-ticket-alt"></i>
                <span>Bookings</span>
            </a>
        </nav>

        <div class="mt-auto border-t border-gray-800 pt-4">
            <a href="../modules/auth/logout.php" class="flex items-center space-x-3 p-3 text-gray-400 hover:text-white">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>

    <main class="flex-1 p-8">
        <header class="flex justify-between items-center mb-10">
            <div>
                <h1 class="text-3xl font-bold">Admin Panel</h1>
                <p class="text-gray-400">Welcome back, Super Admin.</p>
            </div>
            <div class="flex items-center space-x-4">
                <span class="text-sm bg-green-500/20 text-green-400 px-3 py-1 rounded-full border border-green-500/50">System Online</span>
                <div class="w-10 h-10 rounded-full bg-gray-700 border border-gray-600 flex items-center justify-center">
                    <i class="fas fa-user-shield"></i>
                </div>
            </div>
        </header>

        <section class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
            <div class="glass p-6 stat-card">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-gray-400 text-sm">Total Revenue</p>
                        <h3 class="text-2xl font-bold mt-1">$4,250.00</h3>
                    </div>
                    <div class="bg-blue-500/20 p-3 rounded-lg text-blue-400"><i class="fas fa-dollar-sign"></i></div>
                </div>
            </div>
            <div class="glass p-6 stat-card">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-gray-400 text-sm">Active Movies</p>
                        <h3 class="text-2xl font-bold mt-1">24</h3>
                    </div>
                    <div class="bg-purple-500/20 p-3 rounded-lg text-purple-400"><i class="fas fa-video"></i></div>
                </div>
            </div>
            <div class="glass p-6 stat-card">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-gray-400 text-sm">Tickets Sold</p>
                        <h3 class="text-2xl font-bold mt-1">1,120</h3>
                    </div>
                    <div class="bg-green-500/20 p-3 rounded-lg text-green-400"><i class="fas fa-receipt"></i></div>
                </div>
            </div>
            <div class="glass p-6 stat-card">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-gray-400 text-sm">Registered Users</p>
                        <h3 class="text-2xl font-bold mt-1">850</h3>
                    </div>
                    <div class="bg-red-500/20 p-3 rounded-lg text-red-400"><i class="fas fa-users"></i></div>
                </div>
            </div>
        </section>

        <section class="glass p-6">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-xl font-semibold">Recent Bookings</h2>
                <button class="text-sm netflix-red hover:underline">View All</button>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead>
                        <tr class="text-gray-400 border-b border-gray-800">
                            <th class="pb-4">Booking ID</th>
                            <th class="pb-4">User</th>
                            <th class="pb-4">Movie</th>
                            <th class="pb-4">Amount</th>
                            <th class="pb-4">Status</th>
                        </tr>
                    </thead>
                    <tbody class="text-sm">
                        <tr class="border-b border-gray-800/50 hover:bg-white/5 transition">
                            <td class="py-4">#CP-9821</td>
                            <td class="py-4 font-medium">Alex Johnson</td>
                            <td class="py-4">Deadpool & Wolverine</td>
                            <td class="py-4 font-bold text-green-400">$15.00</td>
                            <td class="py-4"><span class="bg-green-500/10 text-green-500 px-2 py-1 rounded">Confirmed</span></td>
                        </tr>
                        <tr class="border-b border-gray-800/50 hover:bg-white/5 transition">
                            <td class="py-4">#CP-9818</td>
                            <td class="py-4 font-medium">Sarah Miller</td>
                            <td class="py-4">Interstellar</td>
                            <td class="py-4 font-bold text-green-400">$12.50</td>
                            <td class="py-4"><span class="bg-yellow-500/10 text-yellow-500 px-2 py-1 rounded">Pending</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
    </main>

</body>

</html>