<?php include "config/db.php"; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CinemaPro | Book Your Movie</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;700&display=swap" rel="stylesheet">
    <style>
        /* ... (Keep your existing CSS exactly as it is) ... */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: #0b0b0b;
            color: white;
            overflow-x: hidden;
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 8%;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(10px);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
        }

        .logo {
            font-size: 26px;
            font-weight: 700;
            color: #ff4d4d;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 30px;
            font-size: 14px;
            font-weight: 500;
            transition: 0.3s;
            padding: 8px 15px;
            border-radius: 5px;
        }

        .nav-links a:hover {
            background: #ff4d4d;
            color: white;
        }

        .hero {
            height: 60vh;
            background: linear-gradient(rgba(0, 0, 0, 0.6), #0b0b0b), url('https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding-top: 80px;
        }

        .hero h1 {
            font-size: 50px;
            margin-bottom: 10px;
        }

        .hero p {
            color: #ccc;
            font-size: 18px;
            max-width: 600px;
        }

        .main-container {
            padding: 50px 8%;
        }

        .section-title {
            margin-bottom: 40px;
            font-size: 28px;
            border-left: 5px solid #ff4d4d;
            padding-left: 15px;
        }

        .movie-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 40px;
        }

        .movie-card {
            background: #1a1a1a;
            border-radius: 15px;
            overflow: hidden;
            position: relative;
            transition: all 0.4s ease;
            cursor: pointer;
            border: 1px solid #333;
        }

        .movie-card:hover {
            transform: scale(1.05);
            border-color: #ff4d4d;
            box-shadow: 0 10px 30px rgba(255, 77, 77, 0.2);
        }

        .movie-img {
            width: 100%;
            height: 400px;
            background: #252525;
            object-fit: cover;
            transition: 0.5s;
        }

        .movie-card:hover .movie-img {
            opacity: 0.4;
            filter: blur(3px);
        }

        .card-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            opacity: 0;
            transition: 0.5s;
            padding: 20px;
            text-align: center;
        }

        .movie-card:hover .card-overlay {
            opacity: 1;
        }

        .card-overlay h3 {
            font-size: 22px;
            margin-bottom: 10px;
            color: #ff4d4d;
        }

        .card-overlay p {
            font-size: 14px;
            margin-bottom: 20px;
            color: #ddd;
        }

        .btn-book {
            background: #ff4d4d;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 50px;
            font-weight: 600;
            font-size: 14px;
        }

        footer {
            text-align: center;
            padding: 40px;
            background: #000;
            color: #555;
            font-size: 13px;
        }

        footer a {
            color: #555;
            text-decoration: none;
        }
    </style>
</head>

<body>

    <nav>
        <div class="logo">CinemaPro</div>
        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="user/login.php">User Login</a>
            <a href="user/register.php" style="background: #ff4d4d;">Sign Up</a>
        </div>
    </nav>

    <header class="hero">
        <h1>Experience Movies Like Never Before</h1>
        <p>Book your tickets for the latest blockbusters in just a few clicks.</p>
    </header>

    <div class="main-container">
        <h2 class="section-title">Now Showing</h2>

        <div class="movie-grid">
            <?php
            $result = mysqli_query($conn, "SELECT * FROM movies");
            while ($row = mysqli_fetch_assoc($result)) {
                // IMPORTANT: Logic to check if image exists in your 'uploads' folder
                // Replace 'uploads/' with the actual folder name where you save images
                $posterPath = "uploads/" . $row['poster'];

                if (!empty($row['poster']) && file_exists($posterPath)) {
                    $posterDisplay = $posterPath;
                } else {
                    $posterDisplay = 'https://via.placeholder.com/300x450?text=No+Poster';
                }
            ?>
                <div class="movie-card">
                    <img src="<?php echo $posterDisplay; ?>" alt="<?php echo $row['title']; ?>" class="movie-img">

                    <div class="card-overlay">
                        <h3><?php echo $row['title']; ?></h3>
                        <p><?php echo $row['genre']; ?> • <?php echo $row['duration']; ?></p>
                        <p style="font-size: 12px; color: #aaa;"><?php echo $row['language']; ?></p>
                        <a href="user/login.php" class="btn-book">Book Now</a>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>

    <footer>
        &copy; 2025 CinemaPro Booking System | <a href="admin/admin_login.php">Admin Staff Login</a>
    </footer>

</body>

</html>