<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$show_id = mysqli_real_escape_string($conn, $_GET['show_id']);

// Fetch show and movie details for the header
$info_query = mysqli_query($conn, "SELECT s.*, m.title FROM shows s JOIN movies m ON s.movie_id = m.movie_id WHERE s.show_id = $show_id");
$info = mysqli_fetch_assoc($info_query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Select Seats - CinemaPro</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: #0f0f0f;
            color: white;
            text-align: center;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: auto;
            background: #1a1a1a;
            padding: 30px;
            border-radius: 15px;
        }

        /* Screen Design */
        .screen {
            width: 80%;
            height: 10px;
            background: #555;
            margin: 20px auto 50px auto;
            border-radius: 50%;
            box-shadow: 0 10px 20px rgba(255, 255, 255, 0.2);
        }

        .screen-text {
            color: #888;
            font-size: 12px;
            margin-bottom: 40px;
            text-transform: uppercase;
        }

        /* Seat Grid */
        .seat-grid {
            display: grid;
            grid-template-columns: repeat(8, 1fr);
            /* 8 seats per row */
            gap: 15px;
            justify-content: center;
            margin-bottom: 40px;
        }

        /* Hide the actual checkbox */
        .seat-container input {
            display: none;
        }

        /* Style the Label as a Seat */
        .seat-label {
            display: block;
            width: 45px;
            height: 40px;
            background: #2ecc71;
            /* Green for Available */
            color: white;
            font-size: 12px;
            line-height: 40px;
            border-radius: 5px 5px 15px 15px;
            /* Looks like a chair */
            cursor: pointer;
            transition: 0.3s;
        }

        .seat-label:hover {
            transform: scale(1.1);
            background: #27ae60;
        }

        /* Color when checkbox is checked */
        .seat-container input:checked+.seat-label {
            background: #f1c40f !important;
            /* Yellow for Selected */
            color: black;
            font-weight: bold;
        }

        /* Color for Booked Seats */
        .booked {
            background: #e74c3c !important;
            /* Red for Booked */
            cursor: not-allowed !important;
            opacity: 0.6;
        }

        /* Legend */
        .legend {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 30px;
            font-size: 14px;
        }

        .legend-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .box {
            width: 15px;
            height: 15px;
            border-radius: 3px;
        }

        .book-btn {
            background: #ff4d4d;
            color: white;
            border: none;
            padding: 15px 50px;
            font-size: 18px;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            transition: 0.3s;
        }

        .book-btn:hover {
            background: #cc0000;
            transform: scale(1.05);
        }
    </style>
</head>

<body>

    <div class="container">
        <h2><?php echo $info['title']; ?></h2>
        <p style="color: #888; margin-bottom: 20px;"><?php echo date("d M", strtotime($info['show_date'])); ?> | <?php echo date("h:i A", strtotime($info['show_time'])); ?></p>

        <div class="screen"></div>
        <p class="screen-text">All eyes this way (Screen)</p>

        <div class="legend">
            <div class="legend-item">
                <div class="box" style="background: #2ecc71;"></div> Available
            </div>
            <div class="legend-item">
                <div class="box" style="background: #f1c40f;"></div> Selected
            </div>
            <div class="legend-item">
                <div class="box" style="background: #e74c3c;"></div> Occupied
            </div>
        </div>

        <form method="post" action="book_ticket.php">
            <input type="hidden" name="show_id" value="<?php echo $show_id; ?>">

            <div class="seat-grid">
                <?php
                $result = mysqli_query($conn, "SELECT * FROM seats WHERE show_id=$show_id");
                while ($row = mysqli_fetch_assoc($result)) {
                    $isBooked = ($row['status'] == 'Booked');
                ?>
                    <div class="seat-container">
                        <input type="checkbox" name="seats[]" value="<?php echo $row['seat_number']; ?>"
                            id="seat-<?php echo $row['seat_id']; ?>" <?php echo $isBooked ? 'disabled' : ''; ?>>

                        <label for="seat-<?php echo $row['seat_id']; ?>"
                            class="seat-label <?php echo $isBooked ? 'booked' : ''; ?>">
                            <?php echo $row['seat_number']; ?>
                        </label>
                    </div>
                <?php } ?>
            </div>

            <button type="submit" name="book" class="book-btn">Confirm Booking</button>
        </form>
    </div>

</body>

</html>