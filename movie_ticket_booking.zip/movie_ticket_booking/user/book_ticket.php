<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || !isset($_POST['book'])) {
    header("Location: dashboard.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$show_id = mysqli_real_escape_string($conn, $_POST['show_id']);
$selected_seats = $_POST['seats']; // This is an array
$seat_string = implode(", ", $selected_seats);
$total_price = count($selected_seats) * 150;

// 1. Insert into Bookings Table
$booking_query = "INSERT INTO bookings (user_id, show_id, seats, booking_date, total_price) 
                  VALUES ($user_id, $show_id, '$seat_string', NOW(), $total_price)";
mysqli_query($conn, $booking_query);

// 2. Update the Seats Table to mark them as 'Booked'
foreach ($selected_seats as $seat_num) {
    mysqli_query($conn, "UPDATE seats SET status='Booked' WHERE show_id=$show_id AND seat_number='$seat_num'");
}

// 3. Fetch Show and Movie details for the ticket display
$details = mysqli_query($conn, "SELECT s.*, m.title FROM shows s JOIN movies m ON s.movie_id = m.movie_id WHERE s.show_id = $show_id");
$info = mysqli_fetch_assoc($details);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Booking Confirmed - CinemaPro</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { 
            background-color: #0f0f0f; 
            height: 100vh; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            color: white; 
        }

        .success-card {
            background: #1a1a1a;
            padding: 40px;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0 15px 35px rgba(0,0,0,0.7);
            max-width: 500px;
            width: 90%;
            border: 1px solid #333;
        }

        .icon-circle {
            width: 80px;
            height: 80px;
            background: #2ecc71;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px auto;
            font-size: 40px;
            box-shadow: 0 0 20px rgba(46, 204, 113, 0.4);
        }

        h2 { color: #2ecc71; margin-bottom: 10px; }
        p { color: #aaa; margin-bottom: 30px; }

        .ticket-details {
            background: #252525;
            padding: 20px;
            border-radius: 12px;
            text-align: left;
            border-left: 5px solid #ff4d4d;
            margin-bottom: 30px;
        }

        .ticket-details div {
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            font-size: 14px;
        }

        .ticket-details span { color: #eee; font-weight: 600; }
        .label { color: #777; font-weight: 400; }

        .btns { display: flex; gap: 15px; }
        .btn {
            flex: 1;
            padding: 12px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: 0.3s;
        }
        .btn-primary { background: #ff4d4d; color: white; border: none; }
        .btn-secondary { background: #333; color: white; }
        .btn:hover { transform: translateY(-3px); opacity: 0.9; }

        @media print {
            .btns, .icon-circle { display: none; }
            body { background: white; color: black; }
            .success-card { border: none; box-shadow: none; }
        }
    </style>
</head>
<body>

<div class="success-card">
    <div class="icon-circle">✓</div>
    <h2>Booking Confirmed!</h2>
    <p>Your tickets have been reserved successfully.</p>

    <div class="ticket-details">
        <div><span class="label">Movie:</span> <span><?php echo $info['title']; ?></span></div>
        <div><span class="label">Date:</span> <span><?php echo date("d M, Y", strtotime($info['show_date'])); ?></span></div>
        <div><span class="label">Time:</span> <span><?php echo date("h:i A", strtotime($info['show_time'])); ?></span></div>
        <div><span class="label">Seats:</span> <span><?php echo $seat_string; ?></span></div>
        <hr style="border: 0; border-top: 1px solid #444; margin: 10px 0;">
        <div><span class="label">Total Paid:</span> <span style="color: #ff4d4d; font-size: 18px;">₹<?php echo $total_price; ?></span></div>
    </div>

    <div class="btns">
        <a href="dashboard.php" class="btn btn-secondary">Home</a>
        <button onclick="window.print()" class="btn btn-primary">Print Ticket</button>
    </div>
</div>

</body>
</html>