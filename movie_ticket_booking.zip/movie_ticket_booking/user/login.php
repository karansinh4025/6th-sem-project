<?php
session_start();
include "../config/db.php";

$error_msg = ""; // To store errors

if (isset($_POST['login'])) {
    // Sanitize input to prevent SQL injection
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    $result = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    $row = mysqli_fetch_assoc($result);

    if ($row && password_verify($password, $row['password'])) {
        $_SESSION['user_id'] = $row['user_id'];

        // Clear any buffers and redirect
        header("Location: dashboard.php");
        exit(); // Always use exit() after header redirect
    } else {
        $error_msg = "Invalid Email or Password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Login - Movie Booking</title>
    <style>
        /* Keep your CSS exactly as you had it here */
        /* ... (I've removed it for brevity, but keep yours) ... */

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-wrapper {
            width: 100%;
            padding: 20px;
            display: flex;
            justify-content: center;
        }

        .login-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            padding: 40px;
            border-radius: 15px;
            width: 100%;
            max-width: 400px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.5);
            color: white;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2rem;
            color: #ff4d4d;
        }

        .input-group {
            position: relative;
            margin-bottom: 25px;
        }

        .input-group label {
            display: block;
            font-size: 14px;
            color: #e0e0e0;
            margin-bottom: 8px;
            font-weight: 500;
            text-align: left;
        }

        .input-group input {
            width: 100%;
            padding: 14px 16px;
            font-size: 16px;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            color: #ffffff;
            outline: none;
            transition: all 0.3s ease-in-out;
        }

        .input-group input:focus {
            background: rgba(255, 255, 255, 0.15);
            border-color: #ff4d4d;
            box-shadow: 0 0 12px rgba(255, 77, 77, 0.4);
        }

        .login-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #ff4d4d 0%, #b30000 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            cursor: pointer;
            transition: all 0.4s;
            box-shadow: 0 4px 15px rgba(255, 77, 77, 0.3);
        }

        .error-msg {
            background: rgba(255, 0, 0, 0.2);
            color: #ff9999;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 0.9rem;
            border: 1px solid rgba(255, 0, 0, 0.3);
        }

        .footer-links {
            margin-top: 20px;
            text-align: center;
        }

        .footer-links a {
            color: #ff4d4d;
            text-decoration: none;
            font-size: 0.9rem;
        }
    </style>
</head>

<body>

    <div class="login-wrapper">
        <div class="login-card">
            <h2>User Login</h2>

            <?php if ($error_msg != ""): ?>
                <div class="error-msg"><?php echo $error_msg; ?></div>
            <?php endif; ?>

            <form method="post" action="login.php">
                <div class="input-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" placeholder="e.g. name@example.com" required>
                </div>

                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="••••••••" required>
                </div>

                <button type="submit" name="login" class="login-btn">
                    Authorize & Login
                </button>
            </form>

            <div class="footer-links">
                <p><a href="register.php">Need an account? Register</a></p>
            </div>
        </div>
    </div>

</body>

</html>