<?php
session_start();
include "../config/db.php";

// Secure the page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$payment_method = $_POST['payment_method'];

// Update your INSERT query to include payment method
$booking_query = "INSERT INTO bookings (user_id, show_id, seats, booking_date, total_price, payment_method) 
                  VALUES ($user_id, $show_id, '$seat_string', NOW(), $total_amount, '$payment_method')";

$user_id = $_SESSION['user_id'];

// Fetch booking history using JOIN to get movie and show details
$query = "SELECT b.*, m.title, m.poster, s.show_date, s.show_time 
          FROM bookings b
          JOIN shows s ON b.show_id = s.show_id
          JOIN movies m ON s.movie_id = m.movie_id
          WHERE b.user_id = $user_id
          ORDER BY b.booking_date DESC";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>My Bookings - CinemaPro</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: #0f0f0f;
            color: white;
            padding-bottom: 50px;
        }

        /* Reuse Navbar Styles */
        nav {
            background: #1a1a1a;
            padding: 15px 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        }

        nav h1 {
            color: #ff4d4d;
            font-size: 24px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            font-size: 14px;
        }

        .container {
            max-width: 900px;
            margin: 40px auto;
            padding: 0 20px;
        }

        h2 {
            margin-bottom: 30px;
            border-left: 5px solid #ff4d4d;
            padding-left: 15px;
        }

        /* Ticket Card Styling */
        .ticket-card {
            background: #1e1e1e;
            display: flex;
            margin-bottom: 25px;
            border-radius: 15px;
            overflow: hidden;
            border: 1px solid #333;
            transition: 0.3s;
        }

        .ticket-card:hover {
            border-color: #ff4d4d;
            transform: scale(1.01);
        }

        .movie-img {
            width: 150px;
            background: #333;
            object-fit: cover;
        }

        .ticket-content {
            padding: 20px;
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .ticket-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 10px;
        }

        .movie-title {
            font-size: 20px;
            font-weight: 600;
            color: #fff;
        }

        .booking-id {
            font-size: 12px;
            color: #777;
            background: #333;
            padding: 2px 8px;
            border-radius: 4px;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-top: 10px;
        }

        .info-item {
            font-size: 14px;
            color: #aaa;
        }

        .info-item span {
            color: #eee;
            font-weight: 500;
            display: block;
        }

        .price-tag {
            text-align: right;
            padding: 20px;
            border-left: 2px dashed #444;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-width: 120px;
        }

        .price-tag p {
            font-size: 12px;
            color: #888;
        }

        .price-tag h3 {
            color: #ff4d4d;
            font-size: 22px;
        }

        .no-bookings {
            text-align: center;
            padding: 50px;
            color: #666;
            font-style: italic;
        }
    </style>
</head>

<body>

    <nav>
        <h1>🎬 CinemaPro</h1>
        <div class="nav-links">
            <a href="dashboard.php">Home</a>
            <a href="my_bookings.php">My Bookings</a>
            <a href="logout.php">Logout</a>
        </div>
    </nav>

    <div class="container">
        <h2>My Booking History</h2>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <div class="ticket-card">
                    <img src="<?php echo !empty($row['poster']) ? $row['poster'] : 'https://via.placeholder.com/150x200?text=Movie'; ?>" class="movie-img">

                    <div class="ticket-content">
                        <div class="ticket-header">
                            <div class="movie-title"><?php echo $row['title']; ?></div>
                            <div class="booking-id">ID: #BK-<?php echo $row['booking_id']; ?></div>
                        </div>

                        <div class="info-grid">
                            <div class="info-item">Date <span><?php echo date("d M, Y", strtotime($row['show_date'])); ?></span></div>
                            <div class="info-item">Time <span><?php echo date("h:i A", strtotime($row['show_time'])); ?></span></div>
                            <div class="info-item">Seats <span><?php echo $row['seats']; ?></span></div>
                            <div class="info-item">Booked On <span><?php echo date("d/m/y", strtotime($row['booking_date'])); ?></span></div>
                        </div>
                    </div>

                    <div class="price-tag">
                        <p>Total Paid</p>
                        <h3>₹<?php echo $row['total_price']; ?></h3>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="no-bookings">
                <p>You haven't booked any movies yet.</p>
                <br>
                <a href="dashboard.php" style="color: #ff4d4d; text-decoration: none;">Browse Movies Now</a>
            </div>
        <?php endif; ?>
    </div>

</body>

</html>